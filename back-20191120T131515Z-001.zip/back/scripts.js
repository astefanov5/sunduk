//функция для подключения любого js файла
function include(url) {
    var script = document.createElement('script');
    script.src = url;
    document.getElementsByTagName('head')[0].appendChild(script);
}

include('send_data.js');//подключаем отправку на сервер

function addRowListener() {
    createDiv(true);
}

const bAddLine = document.querySelector('.button_add_line');//ищем класс
bAddLine.addEventListener('click', addRowListener);//назначаем событию функцию

const bLoadData = document.querySelector('.button_load_data');//ищем класс
bLoadData.addEventListener('click', LoadData);

const bSendData = document.querySelector('.button_send_data');
bSendData.addEventListener('click', send_data);

const number = document.querySelector('.input_number');
number.addEventListener('change', light_number);


var n = 1;
let aDate = [];//массив данных

//проверка значения num
function light_number(){
    //проверяем выход за диапазон
    if (this.value > 100) {
        this.value = '100';
    } else if (this.value < 10){
        this.value = '10';
    }
}

//создание строки в таблице
function createDiv(rowCreate){
    n++;//счетчик

    let div2 = div_tr_1.cloneNode(true);//копируем последний элемент
    if (rowCreate) {
        div2.classList.add('added');
    }

    div2.querySelector('div').innerHTML = n; // счетчик
    //Динамические id
    div2.id = 'div_tr_' + n;
    div2.querySelector('#name_1').id = 'name_' + n;
    div2.querySelector('#select_1').id = 'select_' + n;
    div2.querySelector('#number_1').id = 'number_' + n;
    //
    div2.querySelector('.text_edit').value = '';//шаблон
    div2.querySelector('.input_number').value = 10;//шаблон
    div2.querySelector('.input_number').addEventListener('change', light_number);//проверка диапазона чисел 
    let element = document.getElementById('table');//наша таблица для вставки
    element.append(div2);//вставляем в конец таблицы
}

//загрузка всех данных в массив
function send_data(){
    //проверка пустых полей
    for(i = n; i !== 0; i--) {
        if (table.querySelector('#name_' + (n-i+1)).value === ''){
            alert('Заполните все имена.');
            return false;
        }
    }
    const elements = document.querySelectorAll('.added');
    aDate = [];
    for (const element of elements) {
        let obj = {
            name: element.querySelector('[name="name"]').value,
            select: element.querySelector('[name="city"]').value,
            number: element.querySelector('[name="age"]').value
        };
        aDate.push(obj);
    }
    sendData('senddata.php','POST', aDate);//отправка данных на сервер
    alert('Отправка завершена.');
}

function LoadData(){
    sendData('loaddata.php','GET','', drawData);//запрос данных
}

function drawData(data){
   let dataLoad = JSON.parse(data.responseText);//массив данных с базы
   console.log(dataLoad);
   //чистим старые элементы до 1
   while (n !== 1){
      document.querySelector('#div_tr_' + n).remove();//удаляем
      n--;
   }
   //создаем нужное кол-во элементов без первого
    while (n < dataLoad.length){
       createDiv();
   }
   //заполняем данными
   for(i = n; i !== 0; i--) {
    document.querySelector('#name_'+(n-i+1)).value = dataLoad[n-i][0];//имя
    document.querySelector('#select_'+(n-i+1)).value = dataLoad[n-i][1];//город
    document.querySelector('#number_'+(n-i+1)).value = dataLoad[n-i][2];//возраст
   }
}

LoadData();