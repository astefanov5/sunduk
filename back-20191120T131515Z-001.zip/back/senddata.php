<?php
    require_once 'connection.php'; // подключаем скрипт
    // подключаемся к серверу
    $link = mysqli_connect($host, $user, $password, $database) 
        or die("Ошибка " . mysqli_error($link));
    $data = json_decode($_POST['data'], true);//превращаем данные в массив
    foreach($data as $value){
        $sql  = "INSERT INTO `tablatop` (`name`, `city`, `uage`) VALUES ('" . $value['name'] . "', '" . $value['select'] . "', '" . $value['number'] . "')"; //запрос
        $res = mysqli_query($link, $sql, MYSQLI_USE_RESULT);//отправляем запрос, MYSQLI_USE_RESULT - Готовит результирующий набор на сервере к использованию
    }    
    //$result = mysqli_fetch_all($res);
    //var_dump($result);
        
    // закрываем подключение
    mysqli_close($link);
?>