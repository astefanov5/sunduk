<?php
    $host = '127.0.0.1';
    $database = 'bdddb';
    $user = 'root';
    $password = '';
?>