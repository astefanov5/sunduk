<?php
    require_once 'connection.php'; // подключаем скрипт
    // подключаемся к серверу
    $link = mysqli_connect($host, $user, $password, $database) 
        or die("Ошибка " . mysqli_error($link));
    $sql  = "SELECT * FROM `Age_and_City`"; //запрос
    $res = mysqli_query($link, $sql, MYSQLI_USE_RESULT);//отправляем запрос, MYSQLI_USE_RESULT - Готовит результирующий набор на сервере к использованию
    $result = mysqli_fetch_all($res);
    //var_dump($result);
    echo json_encode($result);
    // закрываем подключение
    mysqli_close($link);
?>